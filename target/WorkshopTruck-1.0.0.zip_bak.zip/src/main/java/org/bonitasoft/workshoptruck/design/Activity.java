package org.bonitasoft.workshoptruck.design;


public class Activity {

}
